CHILL LIFE – current resident bag actions

12 character-only frames, four horizontal 768x256 sheets.
Cell size: 256x256 RGBA. Frame order: bag_open, item_take, item_admire.
Use nearest-neighbor filtering. No horizontal mirroring.

Timing: 700 / 650 / 1800 ms. These are non-uniform pose holds.
Foot/root anchor: (128,236), per cell. Hand, bag opening and held-item anchors are measured in manifest.json.
Denden and Pink use the screen-right active hand. Nyoro and Irukaeru use the screen-left active hand. Side stays consistent for each resident.

Draw the bag and item separately. Each sprite is deliberately empty-handed. Treat heldItemAnchorPx as the prop grip point. Follow the provided continuous line paths; reverse them and frames 2 -> 1 -> 0 to return the same item to the same bag. Do not clone inventory.
Keep Nyoro's existing runtime size multiplier 0.78, others 1.0.

The preview includes current idle references for side-by-side checking; references are not extra animation frames.
Built-in image generation was used for all artwork. Only technical crops, nearest-neighbor scaling and translation were used afterwards. No code painting, recoloring, flipping, alpha thresholding, or replacement facial parts.
Original alpha is retained inside technical crops, including fine edge alpha.

Validation: all 12 distinct frames, all four sheets, native-size visual identity review, empty hands, no added Nyoro mouth, no edge bleed, hand anchors on visible pixels and opaque feet ending at y236. See qa_report.json.
