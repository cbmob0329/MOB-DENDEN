
// Game interaction islands only. Does not modify the document viewport or help/settings.
(function(root){
function installGameGestures(areas, hooks={}){
 const taps=new Map();let lastTouch=-Infinity;
 const cancel=e=>{if(e.cancelable!==false)e.preventDefault()};
 for(const area of areas.filter(Boolean)){
  area.style&&(area.style.touchAction='none');
  for(const n of ['contextmenu','selectstart','dblclick','gesturestart','gesturechange','gestureend'])area.addEventListener(n,cancel,{passive:false,capture:true});
  area.addEventListener('touchstart',e=>{cancel(e);lastTouch=Date.now();for(const t of e.changedTouches){const target=t.target||e.target;const button=target.closest?.('button');taps.set(t.identifier,{x:t.clientX,y:t.clientY,button,moved:false});if(!hooks.pointerSupported&&button?.dataset.action)hooks.down?.('touch:'+t.identifier,button)}},{passive:false,capture:true});
  area.addEventListener('touchmove',e=>{cancel(e);for(const t of e.changedTouches){const tap=taps.get(t.identifier);if(tap&&Math.hypot(t.clientX-tap.x,t.clientY-tap.y)>12)tap.moved=true}},{passive:false,capture:true});
  for(const n of ['touchend','touchcancel'])area.addEventListener(n,e=>{cancel(e);lastTouch=Date.now();for(const t of e.changedTouches){const tap=taps.get(t.identifier);if(!hooks.pointerSupported)hooks.up?.('touch:'+t.identifier,n==='touchcancel');taps.delete(t.identifier);if(n==='touchend'&&tap&&!tap.moved&&tap.button&&!tap.button.dataset.action&&!tap.button.disabled)tap.button.click()}},{passive:false,capture:true});
  // Native touchend default is canceled. Drop any late compatibility click, while
  // preserving keyboard/assistive activation and explicit button.click() (detail 0).
  area.addEventListener('click',e=>{if(e.detail>0&&Date.now()-lastTouch<750){cancel(e);e.stopImmediatePropagation()}},{capture:true,passive:false});
 }
 return {clear(){for(const id of taps.keys())hooks.up?.('touch:'+id,true);taps.clear()}};
}
root.installGameGestures=installGameGestures;if(typeof module!=='undefined')module.exports={installGameGestures};
})(typeof window!=='undefined'?window:globalThis);

