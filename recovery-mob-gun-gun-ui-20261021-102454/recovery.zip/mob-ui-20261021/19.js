
(function(root){'use strict';
// Authored pose contacts, not image bounds: particles/weapons are not body size.
const contacts={mobjessie:[2,2,2],pattyred:[1,1,1],pattyblue:[1,1,1],mobmint:[1,2,4],mobmintTransform:[1,2,4],asamob:[1,2,4],mobguardian:[2,2,2],mobkaijin:[2,1,1],moblilith:[2,2,1],mobtoitira:[2,2,2]};
// Rami staff sweep poses 7-11 follow the current collision window in both forms.
const contactPhases={"mobrami":[[7,8,9,10,11],[7,8,9,10,11],[7,8,9,10,11]],"mobjessie":[[2],[2],[2]],"denden":[[4],[3],[3]],"nyoro":[[3,4],[3],[3,4]],"tetsu":[[3,4],[3,4],[3,4]],"manny":[[2,3],[2,3],[3]],"slime":[[1],[1],[1,2]],"miira":[[1],[1,3],[1]],"miramob":[[1],[1],[1,2]],"pink":[[7,8,9],[8,9,10,11],[7,8,9]],"mobdesert":[[7,8,9],[6,7,8,9],[7,8]],"putinon":[[1],[1],[1]],"pattyred":[[1],[1],[1,2]],"pattyblue":[[1],[1],[1,2]],"mobmint":[[1,2],[2],[4]],"mobmintTransform":[[1,2],[2],[4]],"mobkaijin":[[2],[1,2],[1,2]],"asamob":[[1,2],[2],[4]],"mobguardian":[[2],[2],[2]],"moblilith":[[2],[2],[1,2]],"mobtoitira":[[2],[2],[2]]};
function attackFrame(f,n,d){const key=f.char==='mobmint'&&f.mintForm?'mobmintTransform':f.char,list=contactPhases[key]?.[(f.move.combo||1)-1];if(!list)return null;const valid=list.filter(i=>i<n),first=valid[0],last=valid[valid.length-1],t=f.move.t;if(t<d.active)return Math.min(first-1,Math.floor(t/Math.max(.01,d.active)*first));if(t<=d.end)return valid[Math.min(valid.length-1,Math.floor((t-d.active)/Math.max(.01,d.end-d.active)*valid.length))];return Math.min(n-1,last+1+Math.floor((t-d.end)/Math.max(.01,d.duration-d.end)*Math.max(0,n-last-1)));}
function contact(f,n,fallback){const key=f.char==='mobmint'&&f.mintForm?'mobmintTransform':f.char;return Math.min(n-1,contacts[key]?.[(f.move?.combo||1)-1]??fallback);}
function jump(f,n){if(n===2&&['pattyred','pattyblue'].includes(f.char))return f.animTime<.05?0:1;if(n===6){if(f.animTime<.05)return 0;if(f.vy< -260)return 1;if(f.vy< -80)return 2;if(f.vy<120)return 3;if(f.vy<450)return 4;return 5;}if(n===4)return f.vy< -100?(f.animTime<.07?0:1):Math.abs(f.vy)<=100?2:3;return f.vy<0?0:n-1;}
function run(f,n){const speed=root.Arena?.CHARS[f.char]?.speed||290,ratio=Math.max(.35,Math.min(1.4,Math.abs(f.vx)/speed));return Math.floor(f.animTime*ratio*n/.55)%n;}
root.MobMotionV22={contacts,contactPhases,attackFrame,contact,jump,run};if(typeof module!=='undefined')module.exports=root.MobMotionV22;
})(typeof window!=='undefined'?window:globalThis);

