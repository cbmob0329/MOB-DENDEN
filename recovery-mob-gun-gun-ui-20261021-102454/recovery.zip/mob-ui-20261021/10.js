
(function(root){'use strict';
function effect(ctx,f,reduced){if(!f.kind.startsWith('mochi-'))return false;const p=Math.min(1,f.age/f.duration),r=(f.r||40),dir=f.dir||1;ctx.save();ctx.translate(f.x,f.y);ctx.scale(dir,1);ctx.globalAlpha=Math.min(1,(1-p)*2);ctx.lineWidth=4;ctx.strokeStyle='#fa7dbd';ctx.fillStyle='#fff7df';const n=reduced?5:9;for(let i=0;i<n;i++){const a=i/n*Math.PI*2+p*2,rr=r*(.25+.65*p);ctx.beginPath();ctx.ellipse(Math.cos(a)*rr,Math.sin(a)*rr*.55,4+6*(1-p),3+3*(1-p),a,0,Math.PI*2);ctx.fill();ctx.stroke();}if(f.kind==='mochi-parade'||f.kind==='mochi-birth'){ctx.strokeStyle='#fff3c7';ctx.lineWidth=8*(1-p)+1;ctx.beginPath();ctx.ellipse(0,12,r*(.25+.75*p),r*(.12+.22*p),0,0,Math.PI*2);ctx.stroke();}if(f.kind==='mochi-whip'){ctx.lineWidth=18*(1-p)+4;ctx.strokeStyle='#fff8e6';ctx.beginPath();ctx.moveTo(-r*.6,25);ctx.quadraticCurveTo(r*.65,15,r*.35,-r*.65*p);ctx.stroke();}ctx.restore();return true;}
root.MobV22FX={effect};
})(window);

