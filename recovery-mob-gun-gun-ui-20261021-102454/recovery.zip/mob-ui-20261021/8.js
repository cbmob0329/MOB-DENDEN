
/* v18 authored local vector FX: claw silhouettes and peach-edged sword crescents.
   All marks are bounded in life and position by the engine; reduced FX retains tells. */
(function(root){'use strict';
const TAU=Math.PI*2,GOLD='#f5cf56',PINK='#ff3298',INK='#191725';
function claws(c,r,cross=false){c.lineCap='round';for(let pass=0;pass<2;pass++){c.strokeStyle=pass?'#fff0b6':INK;c.lineWidth=pass?Math.max(2,r*.045):Math.max(6,r*.13);for(let i=0;i<3;i++){let y=(i-1)*r*.32;c.beginPath();c.moveTo(-r*.52,y-r*.36);c.quadraticCurveTo(r*.86,y-r*.13,r*.57,y+r*.47);c.stroke();}if(cross){c.strokeStyle=pass?GOLD:INK;c.beginPath();c.moveTo(-r*.48,r*.57);c.quadraticCurveTo(r*.20,-r*.62,r*.72,-r*.25);c.stroke();}}}
function peach(c,r){c.fillStyle=PINK;c.strokeStyle='#ffbce0';c.lineWidth=Math.max(1.5,r*.09);c.beginPath();c.moveTo(0,-r*.45);c.bezierCurveTo(-r*.85,-r*1.05,-r*1.1,r*.2,0,r);c.bezierCurveTo(r*1.1,r*.2,r*.85,-r*1.05,0,-r*.45);c.fill();c.stroke();c.strokeStyle='#3a1835';c.beginPath();c.moveTo(0,-r*.35);c.quadraticCurveTo(r*.22,r*.2,0,r*.74);c.stroke();c.strokeStyle='#bdff9e';c.beginPath();c.moveTo(0,-r*.48);c.quadraticCurveTo(r*.15,-r*.95,r*.62,-r*.84);c.stroke();}
function blade(c,r,crest=false){c.fillStyle=INK;c.strokeStyle=PINK;c.lineWidth=Math.max(4,r*.09);c.beginPath();c.moveTo(-r*.28,-r);c.bezierCurveTo(r*1.03,-r*.58,r*1.03,r*.58,-r*.28,r);c.quadraticCurveTo(r*.25,0,-r*.28,-r);c.closePath();c.fill();c.stroke();c.strokeStyle='#ffdae9';c.lineWidth=Math.max(2,r*.035);c.beginPath();c.moveTo(-r*.15,-r*.88);c.quadraticCurveTo(r*1.12,0,-r*.15,r*.88);c.stroke();if(crest){c.save();c.translate(r*.17,0);peach(c,r*.31);c.restore();}}
function flecks(c,r,t,color,reduced){if(reduced)return;c.strokeStyle=color;c.lineWidth=2;for(let i=0;i<5;i++){const a=-1.25+i*.62,d=r*(.70+t*.6);c.beginPath();c.moveTo(Math.cos(a)*d,Math.sin(a)*d);c.lineTo(Math.cos(a)*(d+10),Math.sin(a)*(d+10));c.stroke();}}
function projectile(c,p,reduced){if(!['kaijin-shadow-claw','asa-peach-edge','asa-peach-crest'].includes(p.kind))return false;c.save();c.translate(p.x,p.y);c.scale(p.dir||1,1);c.globalAlpha=Math.min(1,Math.max(.35,p.life/.10));const r=p.r;
 if(p.kind==='kaijin-shadow-claw'){if(!reduced){c.save();c.translate(-r*.45,0);c.globalAlpha*=.34;claws(c,r*1.10);c.restore();}claws(c,r*1.18);}
 else{if(!reduced){c.save();c.translate(-r*.40,0);c.globalAlpha*=.28;blade(c,r*.90,false);c.restore();}blade(c,r,p.kind==='asa-peach-crest');}
 c.restore();return true;}
function effect(c,f,reduced){if(!f.kind.startsWith('kaijin-')&&!f.kind.startsWith('asa-'))return false;const age=f.age||0,life=Math.max(.01,age+f.t),t=Math.min(1,age/life),claw=f.kind.startsWith('kaijin-'),r=f.r||40;c.save();c.translate(f.x,f.y);c.scale(f.dir||1,1);c.globalAlpha=Math.min(1,Math.max(0,f.t/.10));
 if(f.kind.endsWith('-tell')){const radius=r*(.48+.25*t);c.globalAlpha*=.48+.45*t;if(claw){claws(c,radius,f.special);}else{c.rotate(-.20);blade(c,radius,f.special);}if(f.special){c.strokeStyle=claw?GOLD:PINK;c.lineWidth=2;c.setLineDash([7,5]);c.beginPath();c.ellipse(0,45,r*.85,8,0,0,TAU);c.stroke();c.setLineDash([]);}}
 else if(f.kind==='asa-bloom'){c.rotate((f.index===1?-.65:.45));for(let i=0;i<(reduced?1:3);i++){c.strokeStyle=i?'#fff0b8':'#ff4da8';c.lineWidth=i?3:10;c.beginPath();c.ellipse(0,0,r*(.5+t*.5),r*.44,i*.18,-1.35,1.4);c.stroke();}if(f.finisher){c.save();c.scale(.55,.55);peach(c,r*.5);c.restore();}flecks(c,r,t,PINK,reduced);}else if(f.kind==='kaijin-rush'){c.strokeStyle=GOLD;c.lineWidth=2;for(let i=0;i<3;i++){c.beginPath();c.moveTo(-r*(1.4+t),i*13-13);c.lineTo(r*.3,i*13-13);c.stroke();}}
 else if(claw){c.rotate((f.index||f.combo||0)%2?-.32:.18);claws(c,r*(.72+t*.3),!!(f.strong||f.finisher));flecks(c,r,t,GOLD,reduced);}
 else{c.rotate(f.strong?-.45:(f.combo||1)%2?-.18:.18);blade(c,r*(.65+t*.3),!!f.finisher);flecks(c,r,t,PINK,reduced);}
 c.restore();return true;}
root.MobV18FX={projectile,effect,claws,blade,peach};if(typeof module!=='undefined')module.exports=root.MobV18FX;
})(typeof window==='undefined'?globalThis:window);

