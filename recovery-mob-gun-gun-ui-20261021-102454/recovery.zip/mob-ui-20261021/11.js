
/* Authored four-phase contact art. Presentation only, shared fairly by all 18 fighters. */
(function(root){'use strict';
const clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
function descriptor(f,reduced=false){let key,size,life=f.duration||.3,bottom=false;
 if(f.kind==='hit'&&!f.status){key=f.strong?'v23Heavy':'v23Light';size=f.strong?138:96;life=f.strong?.28:.22;}
 else if(f.kind==='guard'||f.kind==='pink-shield-block'){key='v23Guard';size=f.text==='PARRY'?112:78;life=.25;}
 else if(f.kind==='counter-attack'){key='v23Counter';size=150;life=.30;}
 else if(f.kind==='ko'){key='v23KO';size=220;life=.55;}
 else if((f.kind==='dust'&&!f.airJump)||f.kind==='touchdown-v23'){key='v23Landing';size=f.kind==='touchdown-v23'?106:82;life=.26;bottom=true;}
 else return null;
 return {key,size:size*(reduced?.75:1),life,bottom,progress:clamp((f.age||0)/life,0,.999),visible:(f.age||0)<life};
}
function effect(c,f,reduced,image){if(f.kind==='counter-ready')return true;const d=descriptor(f,reduced);if(!d)return false;
 if(d.visible&&!image(d.key,f.x,f.y,d.size,0,f.dir||1,d.bottom,clamp((d.life-(f.age||0))/.065,0,1),d.progress))return false;
 // Preserve numerical damage, but lift it above the compact contact rather than hiding the target's face.
 if(f.kind==='hit'&&f.text){c.save();c.globalAlpha=clamp(f.t/.12,0,1);c.font='900 '+(f.strong?20:16)+'px system-ui';c.textAlign='center';c.lineWidth=4;c.strokeStyle='#102437';c.fillStyle=f.armored?'#ffbf72':'#fff7d1';const y=f.y-35-(f.age||0)*42;c.strokeText(String(f.text),f.x,y);c.fillText(String(f.text),f.x,y);c.restore();}
 return true;
}
function counterPlate(c,f,b){if(f.hp<=0||!(f.counter>0))return false;const max=root.Arena?.COUNTER?.parryWindow||.55,ratio=clamp(f.counter/max,0,1),font=Math.max(12,(b.font||14)*.9),w=Math.max(90,Math.min(b.w,180)),height=font+11,x=b.x+(b.w-w)/2,y=b.y+b.h+12;c.save();c.fillStyle='#102c3af2';c.fillRect(x,y,w,height);c.strokeStyle='#8fffe5';c.lineWidth=2;c.strokeRect(x,y,w,height);c.fillStyle='#ffe382';c.fillRect(x+2,y+height-4,(w-4)*ratio,3);c.font='900 '+font+'px system-ui';c.textAlign='center';c.fillStyle='#eefff4';c.fillText(f.control==='p1'?'弱で反撃':'反撃可能',x+w/2,y+font+1);c.restore();return true;}
root.MobV23FX={descriptor,effect,counterPlate};if(typeof module!=='undefined')module.exports=root.MobV23FX;
})(typeof window!=='undefined'?window:globalThis);

