
(function(root){
'use strict';
function stickDirection(dx,dy,radius,deadzone=.23){const distance=Math.hypot(dx,dy),r=Math.max(1,radius),m=Math.min(1,distance/r);if(m<deadzone)return{x:0,y:0,sector:null,dx:0,dy:0};const angle=Math.atan2(dy,dx),sector=(Math.round(angle/(Math.PI/4))+8)%8;return{x:[1,1,0,-1,-1,-1,0,1][sector],y:[0,1,1,1,0,-1,-1,-1][sector],sector,dx:dx/Math.max(distance,r),dy:dy/Math.max(distance,r)};}
function installVirtualStick(el,bank,options={}){let owner=null,wasUp=false;const nub=el.querySelector?.('.stickNub'),actions=['left','right','jump','down'];function releaseActions(){for(const a of actions)bank.releasePointer('stick:'+a);}
 function update(id,x,y){if(id!==owner)return;const b=el.getBoundingClientRect(),r=Math.min(b.width,b.height)*.42,d=stickDirection(x-b.left-b.width/2,y-b.top-b.height/2,r);if(d.y<0&&!wasUp)options.onJump?.();wasUp=d.y<0;releaseActions();for(const [a,on] of [['left',d.x<0],['right',d.x>0],['jump',d.y<0],['down',d.y>0]])if(on)bank.setPointer('stick:'+a,a);if(nub)nub.style.transform=`translate(${d.dx*r*.65}px,${d.dy*r*.65}px)`;el.dataset.direction=d.sector===null?'neutral':String(d.sector);}
 function down(id,x,y){if(options.enabled&&!options.enabled())return false;if(owner!==null)return false;owner=id;update(id,x,y);return true;}
 function up(id){if(id!==owner)return;owner=null;wasUp=false;releaseActions();if(nub)nub.style.transform='translate(0px,0px)';el.dataset.direction='neutral';}
 el.addEventListener('pointerdown',e=>{e.preventDefault();if(owner!==null&&e.pointerId!==owner)up(owner);if(down(e.pointerId,e.clientX,e.clientY)){try{el.setPointerCapture?.(e.pointerId)}catch(_){/* Global release listeners remain authoritative. */}}});
 el.addEventListener('pointermove',e=>{if(e.pointerId===owner){e.preventDefault();update(e.pointerId,e.clientX,e.clientY)}});
 for(const event of ['pointerup','pointercancel','lostpointercapture'])el.addEventListener(event,e=>up(e.pointerId));
 // Releases remain observable even when capture fails or ends outside the stick.
 for(const event of ['pointerup','pointercancel'])root.addEventListener?.(event,e=>up(e.pointerId),true);
 for(const event of ['touchend','touchcancel'])root.addEventListener?.(event,e=>{for(const t of e.changedTouches||[])up('touch:'+t.identifier)},true);
 if(typeof root.PointerEvent!=='function'){
  el.addEventListener('touchstart',e=>{e.preventDefault();if(typeof owner==='string'&&e.touches&&![...e.touches].some(t=>'touch:'+t.identifier===owner))up(owner);for(const t of e.changedTouches)down('touch:'+t.identifier,t.clientX,t.clientY);},{passive:false});
  el.addEventListener('touchmove',e=>{e.preventDefault();for(const t of e.changedTouches)update('touch:'+t.identifier,t.clientX,t.clientY);},{passive:false});
  for(const event of ['touchend','touchcancel'])el.addEventListener(event,e=>{e.preventDefault();for(const t of e.changedTouches)up('touch:'+t.identifier);},{passive:false});
 }
 return{down,move:update,up,clear(){if(owner!==null)up(owner);releaseActions();},get owner(){return owner;}};
}
root.stickDirection=stickDirection;root.installVirtualStick=installVirtualStick;if(typeof module!=='undefined')module.exports={stickDirection,installVirtualStick};
})(typeof window!=='undefined'?window:globalThis);

