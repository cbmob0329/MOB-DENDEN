
(function(root){
function arenaViewport(width,height){const w=Math.max(240,width),h=Math.max(240,height),landscape=w>=h;const scale=landscape?Math.min(w/960,h/480):w/720;return{width:w,height:h,logicalWidth:Math.round(w/scale),logicalHeight:Math.round(h/scale),scale,landscape,touch:Math.max(44,Math.min(58,h*.145,(w-164)/3.1)),stick:Math.max(72,Math.min(152,w*.3,h*.36)),area:w*h};}
root.arenaViewport=arenaViewport;if(typeof module!=='undefined')module.exports={arenaViewport};
})(typeof window!=='undefined'?window:globalThis);

