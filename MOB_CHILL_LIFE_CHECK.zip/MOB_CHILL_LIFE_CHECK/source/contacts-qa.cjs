const fs=require('fs'),assert=require('assert'),{g,c,OriginalTHREE:T,nodes}=require('./qa-harness.cjs');
const views=[[.7,.79],[.25,.97],[1.08,.66],[-.12,.45],[1.42,1.12]];
const out=[];
function prepare(layout,id,key,pose){g.reset();g.setPaused(true);g.actors.forEach(a=>a.timer=1e9);g.room.applyLayout(layout);if(key==='eat')g.placeFood();const a=g.actors[id];g.start(a,key,true);for(let n=0;n<2000;n++){g.advance(.05);if(a.state==='acting'&&((key==='dj'&&a.phase.pose==='dj')||(key==='read'&&a.phase.pose==='read')||(key==='plant'&&a.phase.pose==='garden')||(key==='clean'&&a.phase.pose==='clean')||(key==='eat'&&a.phase.pose==='eat')))break;}if(pose)a.phase.pose=pose;a.phaseTime=Math.max(1,a.phaseTime);return a;}
for(let layout=0;layout<3;layout++)for(let id=0;id<2;id++)for(let [key,pose]of [['dj','dj_a'],['dj','dj_b'],['read','read'],['eat','eat'],['clean','clean'],['plant','garden']]){
 const a=prepare(layout,id,key,pose);const required={read:'read',eat:'eat',clean:'hold',garden:'hold',dj_a:'dj_a',dj_b:'dj_b'}[pose];
 for(let [az,el]of views){g.setView(az,el);g.tick(0);let hand=g.hand(a),metric={layout,id,key,pose,az,el,requiredTextureLoaded:!!a.textures[required],actualTextureMatches:!!a.textures[required]&&a.sprite.material.map===a.textures[required],contact:a.contact||null,footFloor:a.pos.y===0&&Math.abs(a.sprite.position.y-.035)<1e-8};
 if(key==='read')metric.propError=g.book.position.distanceTo(hand);
 if(key==='eat')metric.propError=g.snack.position.distanceTo(hand);
 if(key==='clean'){g.broom.updateMatrixWorld(true);metric.propError=g.broom.localToWorld(new T.Vector3(0,.62,0)).distanceTo(hand);metric.broomGroundY=g.broom.position.y;}
 if(key==='plant'){g.can.updateMatrixWorld(true);metric.propError=g.can.position.distanceTo(hand);metric.pourAboveSoil=g.can.localToWorld(new T.Vector3(-.44,0,0)).y>g.room.socket('plant','water').y;}
 out.push(metric);
 }
}
fs.writeFileSync('qa-contacts-v2.json',JSON.stringify(out,null,2));console.log(JSON.stringify({total:out.length,assetMissing:out.filter(r=>!r.requiredTextureLoaded).length,unsafeDock:out.filter(r=>r.contact&&!r.contact.safe),maxProjectedPx:Math.max(...out.map(r=>r.contact?.projectedErrorPx||0)),maxPropError:Math.max(...out.map(r=>r.propError||0)),maxDepthDifference:Math.max(...out.map(r=>r.contact?.depthDifference||0)),floating:out.filter(r=>!r.footFloor),waterUpward:out.filter(r=>r.key==='plant'&&!r.pourAboveSoil)},null,2));

assert(out.every(r=>r.requiredTextureLoaded&&r.actualTextureMatches&&r.footFloor&&(!r.contact||r.contact.safe)&&(!r.contact||r.contact.projectedErrorPx<1e-8)&&(!('propError' in r)||r.propError<1e-9)&&(r.key!=='plant'||r.pourAboveSoil)));
