/* Pure logic and geometry validation; DOM/rendering are substituted. Not browser visual QA. */
const fs=require('fs'),vm=require('vm'),assert=require('assert'),PNG=require('pngjs').PNG;
const OriginalTHREE=require('./vendor/three.min.js'),pending=[],nodes=new Map();
function element(){let image=null;return {style:{},dataset:{},classList:{add(){},remove(){}},textContent:'',innerHTML:'',hidden:false,children:[],append(...items){this.children.push(...items)},appendChild(x){this.children.push(x)},replaceChildren(...items){this.children=items},addEventListener(){},setPointerCapture(){},showModal(){},close(){},setAttribute(){},getContext(){return {fillRect(){},fillText(){},drawImage(im){image=im},getImageData(){return{data:image.data}}}}}}
const document={body:element(),hidden:false,querySelector(s){if(!nodes.has(s))nodes.set(s,element());return nodes.get(s)},querySelectorAll(){return []},createElement:element,createTextNode:text=>({textContent:text}),addEventListener(){}};
class Renderer{constructor(){this.domElement=element();this.shadowMap={}}setPixelRatio(){}setSize(){}render(){}}
class Loader{load(url,ok){let bytes=Buffer.from(url.split(',')[1],'base64'),im=PNG.sync.read(bytes);pending.push(()=>ok(new OriginalTHREE.Texture({width:im.width,height:im.height,data:im.data})))}}
let seed=1;const Math2=Object.create(Math);Math2.random=()=>{seed=(1664525*seed+1013904223)>>>0;return seed/4294967296};const memory=new Map();
const c={THREE:{...OriginalTHREE,WebGLRenderer:Renderer,TextureLoader:Loader},document,Math:Math2,console,devicePixelRatio:1,innerWidth:390,innerHeight:844,performance:{now:()=>0},requestAnimationFrame:()=>0,localStorage:{getItem:k=>memory.get(k)||null,setItem:(k,v)=>memory.set(k,v),removeItem:k=>memory.delete(k)},addEventListener(){},confirm:()=>true};c.window=c;vm.createContext(c);
for(let f of ['assets/characters.js','room.js','life.js'])vm.runInContext(fs.readFileSync(f,'utf8'),c);pending.forEach(f=>f());const g=c.CHILL;

module.exports={g,c,OriginalTHREE,nodes};
