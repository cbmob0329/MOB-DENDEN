# MOB CHILL LIFE V2 / integrated sprite contract

Release state: CHECK/DEV. Final browser-rendered visual QA is still pending.

## Images

40 transparent 256×256 PNGs, 20 per character. The high-resolution image-generation masters are preserved separately. Game exports use one nearest-neighbor scale per character, never fit individual props/poses to their bounds. No weapon, shield, or baked-in book/food/tool.

Names: idle; walk_front_1/2; walk_side_1/2; walk_back_1/2; sit; bed_mount; sleep; book_reach/hold/read/return; dorayaki_take/eat; dj_a/b; cheer_cheeks/hop.

Walking side faces right and is flipped in code for left travel. Sleep is head-left/feet-right and becomes a horizontal plane aligned with the bed.

## Metadata

`assets/{denden,pink}/meta.json` owns exact normalized foot, hip/seat, sleeping-body-center and per-pose hand anchors measured from exported pixels. Foot anchor is (128,236)/256. Idle visible alpha bounds set the character's displayed height to 1.35 world units; all poses retain the same scale.

The alias table maps book_reach→reach, book_hold→hold, book_read→read, dorayaki_take→food_take, dorayaki_eat→eat, bed_mount→climb, cheer_cheeks→joy, cheer_hop→hop. Metadata handAnchors uses these runtime role names. Clean/garden intentionally reuse the empty-hand hold image and its hand anchor. Window uses the back-facing frame; dance uses the cheerful hopping pose. No missing required frame is treated as complete.

## Contact rendering

`hand()` converts the measured pixel using the actual Sprite center/scale and camera quaternion. The book/snack/cleaning grip/watering can follow that point. Transfer phases move the same existing book or snack object.

For DJ and shelf pickup/return, grounded billboard docking aligns the rendered hand pixel to the furniture socket while preserving floor height. It is a 2D-on-3D contact method, not a skeletal 3D hand. Projected contact error and ray-depth differences are reported separately.

Reading now includes stepping away from the shelf with the book, reading in clear floor space, returning, and replacing it. This avoids the old shelf-board face occlusion. The sleep plane is aligned to the bed with a measured body-center anchor; the seat uses the measured hip anchor.

## Verification

`logic-final-v2.cjs`, `contacts-qa.cjs`, `transfers-qa.cjs`, `support-qa.cjs`, `occlusion-qa.cjs` are non-rendering geometry/logic tests using actual PNG alpha data and real Three.js vectors/meshes. `qa-harness.cjs` supplies a substituted DOM/renderer. They do not claim browser visual verification.

`test.cjs` and `runtime-check.cjs` are the original Windows Edge browser QA entry points, adjusted for the current bed contact height. They must be rerun on this final build on the PC; old reports do not prove the new visuals.
