from pathlib import Path
from PIL import Image
import json,base64,hashlib,re
root=Path(__file__).parent
expected=['idle','walk_front_1','walk_front_2','walk_side_1','walk_side_2','walk_back_1','walk_back_2','sit','bed_mount','sleep','book_reach','book_hold','book_read','book_return','dorayaki_take','dorayaki_eat','dj_a','dj_b','cheer_cheeks','cheer_hop']
assets=json.loads((root/'assets/characters.js').read_text().split('=',1)[1].rstrip(';\n'))
r={'type':'static bytes, dimensions, anchors, and embedded assets; no browser visual QA','characters':[]}
for who in ['denden','pink']:
 packet=assets[who];poses=packet['poses'];meta=packet['meta'];assert sorted(poses)==sorted(expected),f'{who}: missing {set(expected)-set(poses)}'
 row={'name':who,'files':[],'metaAnchors':{k:meta[k] for k in ['footAnchor','sitAnchor','sleepAnchor','handAnchor','handAnchors']}}
 for key in ['footAnchor','sitAnchor','sleepAnchor','handAnchor']:
  assert len(meta[key])==2 and all(0<=n<=1 for n in meta[key]),(who,key)
 for key in ['reach','hold','read','book_return','food_take','eat','dj_a','dj_b']:
  assert key in meta['handAnchors'] and all(0<=n<=1 for n in meta['handAnchors'][key]),(who,key)
 for pose in expected:
  p=root/'assets'/who/(pose+'.png');b=p.read_bytes();assert base64.b64decode(poses[pose].split(',')[1])==b
  im=Image.open(p);assert im.mode=='RGBA' and im.size==(256,256)
  bbox=im.getbbox();assert bbox and bbox[0]>0 and bbox[1]>0 and bbox[2]<256 and bbox[3]<256,(who,pose,bbox)
  sha=hashlib.sha256(b).hexdigest();assert sha==meta['frames'][pose]['sha256']
  row['files'].append({'pose':pose,'bytes':len(b),'bounds':bbox,'sha256':sha})
 for facing in ['front','side','back']:
  assert (root/'assets'/who/(f'walk_{facing}_1.png')).read_bytes()!=(root/'assets'/who/(f'walk_{facing}_2.png')).read_bytes()
 r['characters'].append(row)
h=(root/'MOB_CHILL_LIFE_DEV.html').read_text();r['standaloneBytes']=len(h.encode());r['embeddedImages']=h.count('data:image/png;base64,');r['scripts']=len(re.findall('<script>',h));assert r['embeddedImages']==40 and r['scripts']==4
assert not re.findall(r'<script[^>]+src=|<link[^>]+stylesheet',h)
r['textureRGBABytes']=40*256*256*4;r['mipmaps']=False;r['finalBrowserVisualQA']='NOT RUN'
(root/'qa-final-static-v2.json').write_text(json.dumps(r,ensure_ascii=False,indent=2));print('PASS: 40 images, exact PNG bytes and per-pose anchors, no external scripts/styles, 10MiB texture RGBA')
