MOB CHILL LIFE GAME CENTER
25 pixel-art keychain prize sprites

Contents
- icons/: 25 independent transparent RGBA PNGs, each 256 x 256.
- keychains_atlas.png: transparent 5 x 5 atlas, 256-pixel cells.
- keychains_preview.png: labeled review sheet; labels are separate UI, not sprite artwork.
- manifest.json: IDs, rarity, references, variations, exact source/atlas rectangles, anchors, pixel grid and hashes.
- source_sheets/: the seven generated reference-based sheets.
- prompts/: the seven actual generation prompts.
- SHA256SUMS.txt: integrity hashes.

Import
Use nearest-neighbor filtering. Do not smooth or generate blended mipmaps for inventory display. All final ring centers are [128,24] in 256-pixel local coordinates. Icons are composed of hard 4 x 4 pixel blocks; origin offset is recorded per icon. All visible sprite pixels are within the canvas. Use the manifest rather than assuming raw generated sheet rows align perfectly.

Counts: R 10, SR 8, SSR 5, UR 2.
Stable IDs: R01-R10, SR01-SR08, SSR01-SSR05, UR01-UR02.
Artwork generated from the seven supplied references with the built-in image generator. Only extraction, pixel-grid resampling and packaging were done programmatically. This package contains 2D keychain art, not 3D plush models.
