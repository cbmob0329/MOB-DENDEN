# MOB CHILL LIFE — actual 3D plush prizes

P-01–P-08 completed. Deliverable is **plush-models.js**. All writes stayed in this output folder; game repository and original mummy were not modified.

## Integration
Load existing THREE r160, then inline plush-models.js in the offline HTML. No network or module dependency.

```js
const { group, spec } = ChillPlushModels.create('P-01', THREE);
scene.add(group); // caller owns placement and physics
// When fully removed: ChillPlushModels.dispose(group);
```

IDs use hyphens: P-01 through P-08. Unknown IDs throw. ids and specs are populated at script load. create returns an unattached identity-transform group. All geometry/material/texture instances are independently owned and disposable. P-08 embedded PNG textures load asynchronously from data URLs; normal ongoing rendering displays them on completion. There are no storage accesses or animations. Bounds, estimated COM, torso grip point/radius and compound boxes are in model-manifest.json and spec. No interface changes required.

## Measurements
+Y up, +Z front, feet Y=0. Float32 height error <0.000001.

| ID | triangles | draws | width / height / depth | colliders |
|---|---:|---:|---|---:|
| P-01 | 5596 | 1 | 1.122 / 1.600 / 0.756 | 4 |
| P-02 | 6856 | 1 | 1.042 / 1.600 / 0.948 | 5 |
| P-03 | 4662 | 1 | 1.077 / 1.600 / 1.129 | 6 |
| P-04 | 7582 | 1 | 1.107 / 1.600 / 0.921 | 5 |
| P-05 | 7930 | 1 | 1.108 / 1.600 / 0.702 | 5 |
| P-06 | 6496 | 1 | 1.136 / 1.600 / 0.984 | 6 |
| P-07 | 7696 | 1 | 1.042 / 1.600 / 0.835 | 5 |
| P-08 | 7438 | 2 | 1.413 / 1.600 / 0.878 | 5 |

Total 54256 triangles / 9 model draws for eight simultaneously. Geometry has actual depth. Matte vertex-color cloth for P-01–07; P-08 uses 1024px bandage and 512px eyes. Individual meshes are overlapping sewn-form solids, not a Boolean-unioned manufacturing/watertight surface. No PNG body cards or pedestals.

## Sources and identity
All seven original PNGs were viewed and SHA256 matched; see source-integrity.json. Front/back/side/threequarter actual THREE r160 rendered PNGs were visually inspected.
P-01 green trim and raised paw; P-02 yellow hood and bean snack; P-03 creature suit/yellow belly/back spikes/curved tail/layered snack; P-04 purple hood/headphones/attached two-deck compact console; P-05 red face/cream muzzle and belly/large ears/flames/claws/medallion; P-06 cyan face/yellow eyes/shark helmet/armor/cape/water blaster with NO glasses; P-07 pink glasses/yellow bridge/cassette. PB2 tiny text deliberately omitted per contract. Unspecified backs are simple inferred forms.

P-08 is derived from the approved MUMMY_CAT_GAME.blend, not a procedural replacement. Source inspected: 11,445 triangles, 6,120 vertices, 6,379 polygons, 40 bones, 2 materials. Copied before modification; original SHA256 unchanged. Rest pose baked, skeleton/animations removed, cloth roughness increased, decimated to 7,438 triangles. Working Blender copy: P-08-mummy-plush.blend. Runtime adds 0.94 X compression to that copy to fit 1.45 width; runtime JS/manifest are authoritative.

## Verification and limits
verify.html is a standalone offline page with THREE and models embedded. Console setView('front'|'side'|'back'|'threequarter') changes angle. validation-report.json records successful WebGL2/THREE revision 160, no JS errors, finite vertices, dimensions, zero vertices outside compound boxes, contained grip points, unknown-ID throw and independent transforms/geometry. COM is a uniform-density compound-box volume approximation, not a measured material mass distribution. Boxes intentionally cover accessories conservatively and may contact before the detailed visual surface.

Desktop Edge actual WebGL rendering was tested. Mobile GPU hardware FPS, game physics, claw catching/dropping/restart, storage/inventory/economy/racing integration were **not** tested or changed. Review those in the owning game task. No promise of topology suitability for 3D printing. Tiny geometric details and cloth shading are simplified for mobile budgets.

## Editable/rebuild files
plush-source.js + mummy-data.json; build-verify.cjs builds JS/manifest/page/previews. convert_mummy.py creates the static Blender copy and embedded mesh source. finalize.cjs records provenance and this README. Build script uses already installed Playwright/Edge and local THREE; installs nothing. Only plush-models.js is needed by runtime.
