CHILL LIFE reference pack

Contents
- references/: seven exact, unchanged user-supplied PNGs.
- production_plan.json: proposed 25 pixel keychains (R10, SR8, SSR5, UR2) and eight real-3D plush prize configurations.
- reference_inventory.json: source filenames, Library identity, original cloud-inspection paths, dimensions and SHA-256 checksums. The original workspace paths are provenance only; use the relative references/ paths in this pack on your PC.

Placement
Extract this ZIP into the game project's chosen asset/reference folder. Keep the seven PNGs as source references. This pack does not include generated keychain sprites, 3D meshes or executable code.

Source mapping: one character in each PNG, seven characters total
REF-01 = references/01(20261007-134501).png
  Black face, gold round glasses, charcoal cat-ear hoodie with neon-green trim, raised paw.
REF-02 = references/22(20261007-134502).png
  Black face, gold round glasses, black/yellow cat-ear hoodie, large round bean-filled snack.
REF-03 = references/55(20261007-134504).png
  Black face, gold round glasses, cyan creature costume with yellow belly, spikes and tail, layered round snack.
REF-04 = references/59(3).png
  Black face, gold round glasses, purple cat-ear hoodie, headphones and twin-turntable DJ console.
REF-05 = references/40(9).png
  Red large-eared flame creature, cream muzzle/belly, gold round glasses, flame head/tail, flame medallion. No black face or hoodie.
REF-06 = references/41(10).png
  Cyan smiling face, yellow eyes, shark-shaped knight headgear, blue/white/gold armor and cape, water blaster. No glasses.
REF-07 = references/38(20261007-134509).png
  Black face, pink round glasses, black/pink cat-ear outfit, cassette labeled PB2.

All seven sources include a display pedestal marked MOB. Do not automatically attach those display pedestals to catchable plush prizes.

Proposed real-3D plush prizes
P-01: REF-01, original charcoal/neon-green hood and gold glasses.
P-02: REF-02, original black/yellow hood and a soft, attached snack prop.
P-03: REF-03, cyan creature costume, yellow belly and soft, attached layered-snack prop.
P-04: REF-04, purple hoodie, soft headphone shapes and compact attached DJ-console prop.
P-05: REF-05, red/cream flame creature, gold glasses and felt-like head/tail flames.
P-06: REF-06, cyan face, shark hood, softened armor/cape and attached water-blaster prop; no glasses.
P-07: REF-07, black/pink cat hood, pink glasses and attached PB2 cassette.
P-08: provisional cyan-trim colorway of P-01. This is an eighth prize variant, not an eighth supplied character reference.

3D implementation requirements
The PNGs are raster reference illustrations. A PNG, flat card or billboard is not a 3D plush model. Build real rounded body/head/limb/hood/prop geometry with cloth-like matte materials, readable face details and stable collision bodies. Verify depth and silhouette from front, side and back, then test claw contact, grasp, drop and prize detection.

Cost-conscious reuse
Four reusable base-mesh families can cover the eight prize variants: hooded, rounded creature suit, flame creature and shark knight. Reuse materials and geometry where possible while preserving source-specific faces, glasses, head silhouettes, clothing and props. No official names or unseen back-view details are supplied. All extra color/clothing/prop variants in the production plan are proposals, not additional observed references.
